BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS app_users (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), username text NOT NULL UNIQUE,
 password_hash text NOT NULL, role text NOT NULL CHECK(role IN ('ADMIN','ACCOUNTANT','VIEWER')),
 totp_secret_enc bytea, totp_enabled boolean NOT NULL DEFAULT false,
 disabled_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS companies (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL,
 functional_currency char(3) NOT NULL DEFAULT 'YER', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS company_members (
 company_id uuid NOT NULL REFERENCES companies(id), user_id uuid NOT NULL REFERENCES app_users(id),
 role text NOT NULL CHECK(role IN ('ADMIN','ACCOUNTANT','VIEWER')),
 PRIMARY KEY(company_id,user_id)
);
CREATE TABLE IF NOT EXISTS accounts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES companies(id),
 code text NOT NULL, name text NOT NULL, currency char(3) NOT NULL,
 active boolean NOT NULL DEFAULT true, UNIQUE(company_id,code)
);
CREATE TABLE IF NOT EXISTS documents (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), company_id uuid NOT NULL REFERENCES companies(id),
 doc_type text NOT NULL, doc_no text NOT NULL, status text NOT NULL CHECK(status IN ('POSTED','REVERSED')),
 currency char(3) NOT NULL, exchange_rate numeric(24,8) NOT NULL CHECK(exchange_rate>0),
 source_device_id text, idempotency_key text NOT NULL, payload jsonb NOT NULL,
 created_by uuid NOT NULL REFERENCES app_users(id), created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(company_id,idempotency_key), UNIQUE(company_id,doc_type,doc_no)
);
CREATE TABLE IF NOT EXISTS journal_lines (
 id bigserial PRIMARY KEY, company_id uuid NOT NULL REFERENCES companies(id),
 document_id uuid NOT NULL REFERENCES documents(id), account_id uuid NOT NULL REFERENCES accounts(id),
 line_no integer NOT NULL, description text NOT NULL DEFAULT '', currency char(3) NOT NULL,
 debit numeric(24,4) NOT NULL DEFAULT 0 CHECK(debit>=0), credit numeric(24,4) NOT NULL DEFAULT 0 CHECK(credit>=0),
 base_debit numeric(24,4) NOT NULL DEFAULT 0 CHECK(base_debit>=0), base_credit numeric(24,4) NOT NULL DEFAULT 0 CHECK(base_credit>=0),
 CHECK ((debit=0 AND credit>0) OR (credit=0 AND debit>0)),
 UNIQUE(document_id,line_no)
);
CREATE INDEX IF NOT EXISTS journal_lines_company_account_idx ON journal_lines(company_id,account_id,id);
CREATE INDEX IF NOT EXISTS documents_company_created_idx ON documents(company_id,created_at DESC,id DESC);
CREATE TABLE IF NOT EXISTS audit_chain (
 seq bigserial PRIMARY KEY, company_id uuid NOT NULL REFERENCES companies(id), actor_id uuid NOT NULL REFERENCES app_users(id),
 event_type text NOT NULL, entity_id uuid, payload jsonb NOT NULL,
 prev_hash bytea NOT NULL, event_hash bytea NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_chain_company_seq_idx ON audit_chain(company_id,seq);
CREATE TABLE IF NOT EXISTS idempotency_records (
 company_id uuid NOT NULL REFERENCES companies(id), key text NOT NULL, response jsonb NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(company_id,key)
);
CREATE TABLE IF NOT EXISTS backup_runs (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), status text NOT NULL CHECK(status IN ('STARTED','SUCCEEDED','FAILED')),
 object_key text, checksum_sha256 text, error_code text, started_at timestamptz NOT NULL DEFAULT now(), finished_at timestamptz
);
CREATE OR REPLACE FUNCTION deny_mutation_audit_chain() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'audit_chain is append-only'; END $$;
DROP TRIGGER IF EXISTS audit_chain_no_update_delete ON audit_chain;
CREATE TRIGGER audit_chain_no_update_delete BEFORE UPDATE OR DELETE ON audit_chain FOR EACH ROW EXECUTE FUNCTION deny_mutation_audit_chain();
COMMIT;
