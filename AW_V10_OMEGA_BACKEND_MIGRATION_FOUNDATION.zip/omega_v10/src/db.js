import pg from 'pg';
const {Pool}=pg;
if(!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required');
export const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.PGSSL==='disable'?false:{rejectUnauthorized:true},max:Number(process.env.PGPOOL_MAX||10),idleTimeoutMillis:30000,connectionTimeoutMillis:5000});
pool.on('error',e=>{process.stderr.write(JSON.stringify({level:'error',event:'pg_pool_error',message:e.message})+'\n')});
