import {hashAudit} from './security.js';

// Call only inside the same transaction as the business mutation. The advisory
// transaction lock serializes each company's chain, including the empty-chain case.
export async function appendAudit(client,{companyId,actorId,eventType,entityId=null,payload}){
  await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))',[companyId]);
  const r=await client.query(
    'SELECT event_hash FROM audit_chain WHERE company_id=$1 ORDER BY seq DESC LIMIT 1',
    [companyId]
  );
  const prev=r.rowCount?Buffer.from(r.rows[0].event_hash):Buffer.alloc(32);
  const body={companyId,actorId,eventType,entityId,payload};
  const eventHash=hashAudit(prev,body);
  await client.query(
    'INSERT INTO audit_chain(company_id,actor_id,event_type,entity_id,payload,prev_hash,event_hash) VALUES($1,$2,$3,$4,$5,$6,$7)',
    [companyId,actorId,eventType,entityId,payload,prev,eventHash]
  );
  return {previousHash:prev.toString('hex'),eventHash:eventHash.toString('hex')};
}
