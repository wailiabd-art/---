import crypto from 'node:crypto';
import {SignJWT,jwtVerify} from 'jose';
export const auditKey=()=>{const s=process.env.AUDIT_HMAC_KEY;if(!s||Buffer.from(s,'base64').length<32)throw new Error('AUDIT_HMAC_KEY must be base64-encoded 32+ bytes');return Buffer.from(s,'base64')};
export const jwtKey=()=>{const s=process.env.JWT_SECRET;if(!s||Buffer.byteLength(s)<32)throw new Error('JWT_SECRET must be 32+ bytes');return new TextEncoder().encode(s)};
function canonicalJson(value){
 if(value===null||typeof value!=='object') return JSON.stringify(value);
 if(Array.isArray(value)) return '['+value.map(canonicalJson).join(',')+']';
 return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonicalJson(value[k])).join(',')+'}';
}
export function hashAudit(prevHash,entry){return crypto.createHmac('sha256',auditKey()).update(prevHash).update('\n').update(canonicalJson(entry)).digest()}
export function verifyAuditHash(prevHash,entry,expectedHex){return crypto.timingSafeEqual(hashAudit(prevHash,entry),Buffer.from(expectedHex,'hex'))}
export async function issueToken(user){return new SignJWT({role:user.role,username:user.username}).setProtectedHeader({alg:'HS256'}).setSubject(user.id).setIssuedAt().setIssuer(process.env.JWT_ISSUER||'aw-omega-v10').setAudience('aw-omega-client').setExpirationTime('15m').setJti(crypto.randomUUID()).sign(jwtKey())}
export async function verifyToken(token){return jwtVerify(token,jwtKey(),{issuer:process.env.JWT_ISSUER||'aw-omega-v10',audience:'aw-omega-client'})}
