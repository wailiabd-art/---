import fs from 'node:fs/promises';import path from 'node:path';import {fileURLToPath} from 'node:url';import {pool} from './db.js';
const here=path.dirname(fileURLToPath(import.meta.url));
try{const sql=await fs.readFile(path.join(here,'../migrations/001_core.sql'),'utf8');await pool.query(sql);process.stdout.write('MIGRATION_PASS 001_core.sql\n')}catch(e){process.stderr.write(`MIGRATION_FAIL ${e.message}\n`);process.exitCode=1}finally{await pool.end()}
