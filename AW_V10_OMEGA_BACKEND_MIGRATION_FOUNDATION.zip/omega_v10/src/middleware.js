import {verifyToken} from './security.js';
export async function authenticate(req,res,next){try{const h=req.headers.authorization||'';if(!h.startsWith('Bearer '))return res.status(401).json({error:'AUTH_REQUIRED'});const {payload}=await verifyToken(h.slice(7));req.user={id:payload.sub,role:payload.role,username:payload.username};next()}catch{return res.status(401).json({error:'AUTH_INVALID_OR_EXPIRED'})}}
export const requireRole=(...roles)=>(req,res,next)=>roles.includes(req.user?.role)?next():res.status(403).json({error:'FORBIDDEN'});
