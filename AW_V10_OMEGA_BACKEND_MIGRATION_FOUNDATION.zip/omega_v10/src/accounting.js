// Monetary comparisons use fixed-point integers (4 decimal places), never binary-float sums.
export function moneyToUnits(value) {
  const text = typeof value === 'number' ? value.toString() : String(value);
  if (!/^(?:0|[1-9]\d*)(?:\.\d{1,4})?$/.test(text)) throw new TypeError('INVALID_MONEY');
  const [whole, fraction = ''] = text.split('.');
  return BigInt(whole) * 10000n + BigInt((fraction + '0000').slice(0, 4));
}
export function isBalancedBaseCurrency(lines) {
  try {
    const debit = lines.reduce((sum, line) => sum + moneyToUnits(line.baseDebit), 0n);
    const credit = lines.reduce((sum, line) => sum + moneyToUnits(line.baseCredit), 0n);
    return debit === credit && debit > 0n;
  } catch {
    return false;
  }
}
export function hasValidSingleSide(line) {
  try {
    const debit = moneyToUnits(line.debit);
    const credit = moneyToUnits(line.credit);
    return (debit === 0n && credit > 0n) || (credit === 0n && debit > 0n);
  } catch {
    return false;
  }
}
