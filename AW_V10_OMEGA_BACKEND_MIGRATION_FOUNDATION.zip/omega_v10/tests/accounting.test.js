import test from 'node:test';
import assert from 'node:assert/strict';
import {isBalancedBaseCurrency,hasValidSingleSide,moneyToUnits} from '../src/accounting.js';

test('balanced base currency is accepted exactly',()=>assert.equal(isBalancedBaseCurrency([{baseDebit:100,baseCredit:0},{baseDebit:0,baseCredit:100}]),true));
test('unbalanced base currency is rejected exactly',()=>assert.equal(isBalancedBaseCurrency([{baseDebit:100,baseCredit:0},{baseDebit:0,baseCredit:99.9999}]),false));
test('fractional values are compared without epsilon',()=>assert.equal(isBalancedBaseCurrency([{baseDebit:'0.1001',baseCredit:0},{baseDebit:0,baseCredit:'0.1000'}]),false));
test('zero/zero line is invalid',()=>assert.equal(hasValidSingleSide({debit:0,credit:0}),false));
test('single-sided line is valid',()=>assert.equal(hasValidSingleSide({debit:12.5,credit:0}),true));
test('money converts to fixed-point integer units',()=>assert.equal(moneyToUnits('12.3401'),123401n));
test('more than four decimal places is rejected',()=>assert.throws(()=>moneyToUnits('1.00001'),/INVALID_MONEY/));
