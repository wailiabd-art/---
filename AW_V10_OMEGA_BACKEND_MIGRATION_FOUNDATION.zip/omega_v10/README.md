# AW Phoenix V10.0 — Backend Migration Foundation (NOT A PRODUCTION RELEASE)

This is a backend implementation foundation for migrating the existing AW V9.44.15 client from browser-local authority to PostgreSQL. It is intentionally not labelled production-ready: the legacy app's complete domain contract has not yet been migrated, no live server or cloud bucket has been provisioned, and no legacy database has been imported.

## Included
- PostgreSQL schema for users, companies, memberships, accounts, posted documents, journal lines, append-only audit chain, idempotency records and backup runs.
- API login using Argon2 password hashes, short-lived signed JWTs, rate limiting and role checks. MFA-enabled accounts are safely refused pending a TOTP challenge flow; MFA is not falsely claimed complete.
- Atomic document posting in one PostgreSQL transaction, company membership checks, account checks, base-currency balancing, idempotency keys and HMAC audit chain.
- Server-side paginated document listing.
- Docker Compose for a local development stack.

## Deliberately not done / release blockers
1. No deployed PostgreSQL, TLS endpoint, firewall, secrets manager, or S3-compatible bucket exists from this package alone.
2. The existing V9.44.15 HTML has not been switched to this API. Do not disable local storage or use this backend with live accounting until a tested migration/import and client adapter are completed.
3. The complete legacy posting/reversal/correction/document-numbering/treasury/settlement/reporting semantics are not all implemented in this foundation. The generic posting endpoint is not a substitute for that full domain migration.
4. TOTP enrollment/verification/recovery, session revocation, password reset, account provisioning, and least-privilege database roles require implementation before production.
5. Automated encrypted S3 backups, restore drills, PITR/WAL archiving, retention and alerting are not wired yet.
6. HMAC is server-side but a privileged database owner can still alter records and application keys; use separate DB roles, external immutable/WORM storage for audit checkpoints, KMS-managed secrets and independent monitoring.
7. Migration from the legacy SQLite/WASM database is not implemented. Never import production data until schema mapping, reconciliation, dry-run and rollback procedures are approved and tested.

## Run local development only
1. Copy `.env.example` to `.env` and replace all values with random secrets.
2. `docker compose -f ops/docker-compose.yml up --build -d`
3. Apply schema: `docker compose -f ops/docker-compose.yml exec api node src/migrate.js`
4. This stack creates no admin user by default. Provisioning is intentionally not exposed as an unauthenticated endpoint.

Before production: add TLS 1.3 reverse proxy, MFA flow, provisioning, production DB role separation, migration tooling, domain parity, encrypted backup/restore tests, E2E, load/security tests and deployment-specific secret configuration.

## Additional correctness controls in this package
- Monetary balance validation uses fixed-point integer units at four decimal places rather than an epsilon-based floating-point comparison.
- Audit-chain writes are serialized per company with a transaction-scoped PostgreSQL advisory lock.
- HMAC input uses canonical JSON key ordering.
- Document pagination uses a compound timestamp/UUID cursor.

These controls improve the foundation but do not replace PostgreSQL integration tests, concurrency tests, independent audit verification, client integration, backup/restore drills, or production deployment hardening.
